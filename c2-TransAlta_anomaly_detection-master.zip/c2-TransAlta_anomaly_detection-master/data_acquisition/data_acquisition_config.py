"""
Any config specific to data acquisition step goes here.
"""

SUBSCRIPTION_ID = 'f17fb002-6ef1-424c-b174-afccfd751092'
RESOURCE_GROUP = 'TransaltaAAILabs'
WORKSPACE_NAME = 'Transalta-AAILabs'
DATASET_NAME = "melancthon"
